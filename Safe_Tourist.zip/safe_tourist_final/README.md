# 🛡️ SafeTrail — Smart Tourist Safety System
**Navi Mumbai Tourist Safety App** | Flask + SQLite + Leaflet.js

---

## 📁 Project Structure

```
safe_tourist_final/
├── Backend/
│   ├── App.py              ← Flask server (port 5500)
│   └── requirements.txt    ← Python dependencies
├── Frontend/
│   ├── index.html          ← Home + Register/Login
│   ├── map.html            ← Live GPS map + distress detection
│   ├── sos.html            ← SOS emergency trigger
│   ├── hotels.html         ← Hotels by city (API-connected)
│   └── services.html       ← Hospitals, police, pharmacy (API-connected)
├── Database/
│   └── schema.sql          ← SQLite schema (auto-created on first run)
├── start.bat               ← Windows quick-start
└── README.md
```

---

## 🚀 Setup & Run

### 1. Install Python (3.8+)
Download from https://python.org if not installed.

### 2. Install dependencies
```bash
cd Backend
pip install -r requirements.txt
```

### 3. Start the server
```bash
python App.py
```
Or on Windows, just double-click **`start.bat`**

### 4. Open the app
Visit **http://127.0.0.1:5500** in your browser.

---

## 🔗 All Pages

| Page | URL |
|------|-----|
| Home / Register / Login | http://127.0.0.1:5500/ |
| Live Map | http://127.0.0.1:5500/map.html |
| SOS Emergency | http://127.0.0.1:5500/sos.html |
| Hotels | http://127.0.0.1:5500/hotels.html |
| Services | http://127.0.0.1:5500/services.html |
| Admin Stats API | http://127.0.0.1:5500/api/admin/stats |

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/register` | Register new tourist |
| POST | `/api/login` | Login with phone number |
| GET | `/api/cities` | List all cities |
| GET | `/api/city/<city>/services` | Services for a city |
| GET | `/api/city/<city>/services?type=hotel` | Filter by type |
| POST | `/api/location/update` | Update live GPS location |
| GET | `/api/location/history/<uid>` | Location history |
| POST | `/api/sos/trigger` | Trigger SOS alert |
| POST | `/api/distress/report` | Auto-distress report |
| GET | `/api/admin/stats` | Admin dashboard stats |

---

## 📧 Email Alerts (Optional)
To enable real email alerts, edit `Backend/App.py`:
```python
SENDER_EMAIL    = "your_app_email@gmail.com"
SENDER_PASSWORD = "your_gmail_app_password"   # Use App Password, not your login password
EMAIL_ENABLED   = True
```
> Use a Gmail **App Password**: Google Account → Security → 2FA → App Passwords

---

## 🛠️ Fixes Applied
1. **Backend `distress_report`** — fixed bug where `AUTO_DISTRESS` type was ignored
2. **services.html** — now fetches from `/api/city/:city/services` with city selector; static fallback if offline
3. **hotels.html** — now fetches from `/api/city/:city/services?type=hotel`; static fallback if offline
4. **index.html** — added **Login tab** connected to `/api/login`; register uses `BASE_URL` constant
5. **All frontend files** — replaced hardcoded `http://127.0.0.1:5500` with `BASE_URL` constant
6. **CRLF line endings** — converted to LF for cross-platform compatibility
7. **`requirements.txt`** — added for easy dependency install
8. **`start.bat`** — Windows one-click startup script
